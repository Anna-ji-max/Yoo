# Instagram Focus Mode

An Android AccessibilityService companion app for Instagram.

## What this prototype does

- Leaves Instagram's bottom navigation area uncovered.
- Main feed: vertical/horizontal movement is consumed while taps are replayed to Instagram.
- Stories: only horizontal swipes are replayed; vertical swipes are consumed.
- Detects Explore/Reels-related accessibility labels and shows a motivational screen.
- Detects likely other-profile screens and masks the content area above the bottom navigation.
- Detects likely Story screens and masks the content area while preserving the bottom navigation area.
- Watches scroll events and can open Instagram Direct Messages when a recent accessibility event contains a shared-reel marker.
- Uses `android:notificationTimeout="20"` and a lightweight main-thread handler to reduce avoidable delay.

## Important Android limitation

A third-party Android app cannot reliably guarantee a 20 ms end-to-end response time or perfectly intercept every Instagram gesture. Accessibility events are delivered according to Android and Instagram scheduling, and Instagram can change its UI hierarchy without notice.

This project is therefore a prototype/restriction layer, not a modified Instagram client.

## Build with GitHub Actions

1. Create a GitHub repository.
2. Upload this project.
3. Commit to `main`.
4. Open **Actions → Build Android APK**.
5. Download the `instagram-focus-mode-debug` artifact.

The workflow filename is:

`.github/workflows/build-apk.yml`

## Install

Enable the app under:

Settings → Accessibility → Installed apps / Downloaded apps → Instagram Focus Mode

Then open Instagram.

## Tuning

The heuristics in `FocusAccessibilityService.kt` may need updating if Instagram changes labels such as:
- Explore
- Reels
- Stories
- Followers / Following
- Edit profile
- Shared a reel / Sent you a reel

Do not ship an accessibility service to production without checking the current Google Play Accessibility API policy and Instagram's terms.
