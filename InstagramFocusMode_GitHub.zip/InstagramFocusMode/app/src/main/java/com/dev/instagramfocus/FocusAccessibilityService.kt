package com.dev.instagramfocus

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.FrameLayout
import android.content.Intent
import android.net.Uri

/**
 * Prototype Instagram restriction layer.
 *
 * Important:
 * - This does NOT modify Instagram.
 * - It uses Android AccessibilityService + TYPE_ACCESSIBILITY_OVERLAY.
 * - Instagram can change view labels/structure at any time, so detection is intentionally
 *   based on several signals and should be updated when Instagram's UI changes.
 */
class FocusAccessibilityService : AccessibilityService() {

    companion object {
        private const val INSTAGRAM = "com.instagram.android"
        private const val NAV_HEIGHT_DP = 88
        private const val MESSAGE_MS = 900L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlay: FrameLayout? = null
    private var lastWindowClass: String? = null
    private var lastEventWasSharedReel = false
    private var lastMessageAt = 0L
    private var mode = Mode.NONE
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L

    private enum class Mode { NONE, FEED_LOCK, STORY_HORIZONTAL, PROFILE_LOCK, BLOCK_SCREEN }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            notificationTimeout = 20
            flags = flags or
                android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != INSTAGRAM) {
            removeOverlay()
            return
        }

        val type = event.eventType
        val textBlob = buildString {
            event.text?.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it).append(' ') }
            append(event.className ?: "")
        }.lowercase()

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastWindowClass = event.className?.toString()
        }

        lastEventWasSharedReel = lastEventWasSharedReel ||
                textBlob.contains("sent you a reel") ||
                textBlob.contains("shared a reel") ||
                textBlob.contains("reel with you") ||
                textBlob.contains("reel sent")

        when (type) {
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // If Instagram exposes a shared-reel marker immediately before a scroll,
                // take the user to Direct Messages instead of allowing the next navigation.
                if (lastEventWasSharedReel) {
                    lastEventWasSharedReel = false
                    openDirectMessages()
                    return
                }
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                refreshOverlay(textBlob)
            }
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun refreshOverlay(textBlob: String) {
        mainHandler.post {
            when {
                isExploreOrReelsTab(textBlob) -> {
                    mode = Mode.BLOCK_SCREEN
                    showOverlay("Stay connected, not endlessly scrolling.", opaque = true)
                }
                looksLikeOtherProfile(textBlob) -> {
                    mode = Mode.PROFILE_LOCK
                    showOverlay("Profile posts and reels are hidden in Focus Mode.", opaque = true)
                }
                looksLikeStory(textBlob) -> {
                    mode = Mode.STORY_HORIZONTAL
                    showOverlay("Story mode: horizontal swipe only.", opaque = false)
                }
                else -> {
                    // Main feed: keep Instagram visible, but intercept vertical swipes.
                    mode = Mode.FEED_LOCK
                    showOverlay(null, opaque = false)
                }
            }
        }
    }

    private fun isExploreOrReelsTab(blob: String): Boolean {
        // Use stronger combinations to avoid treating ordinary feed events as the
        // Explore/Search/Reels destination.
        return blob.contains("reels") ||
                blob.contains("explore") ||
                blob.contains("search and explore") ||
                blob.contains("reels and videos")
    }

    private fun looksLikeOtherProfile(blob: String): Boolean {
        val profileSignals =
            blob.contains("followers") &&
            (blob.contains("following") || blob.contains("posts"))
        val ownSignals =
            blob.contains("edit profile") ||
            blob.contains("professional dashboard") ||
            blob.contains("share profile")
        return profileSignals && !ownSignals
    }

    private fun looksLikeStory(blob: String): Boolean {
        return blob.contains("story") ||
                blob.contains("stories") ||
                blob.contains("close friends")
    }

    private fun showOverlay(message: String?, opaque: Boolean) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (overlay == null) {
            overlay = FrameLayout(this).apply {
                setBackgroundColor(Color.TRANSPARENT)
                isClickable = true
                setOnTouchListener { _, event -> handleOverlayTouch(event) }
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(overlay, lp)
        }

        val root = overlay ?: return
        root.removeAllViews()

        val content = FrameLayout(this).apply {
            setBackgroundColor(
                if (opaque) Color.argb(248, 10, 14, 26) else Color.TRANSPARENT
            )
            isClickable = false
        }

        if (message != null) {
            val tv = TextView(this).apply {
                text = message
                textSize = 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(50, 30, 50, 30)
            }
            content.addView(
                tv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        // Never cover Instagram's bottom navigation.
        val navHeight = (NAV_HEIGHT_DP * resources.displayMetrics.density).toInt()
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        lp.bottomMargin = navHeight
        root.addView(content, lp)
    }

    private fun handleOverlayTouch(event: android.view.MotionEvent): Boolean {
        when (event.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                downTime = android.os.SystemClock.uptimeMillis()
                return true
            }

            android.view.MotionEvent.ACTION_UP -> {
                val x = event.rawX
                val y = event.rawY
                val dx = x - downX
                val dy = y - downY
                val duration = (android.os.SystemClock.uptimeMillis() - downTime).coerceIn(80L, 700L)

                when (mode) {
                    Mode.STORY_HORIZONTAL -> {
                        if (kotlin.math.abs(dx) > kotlin.math.abs(dy) &&
                            kotlin.math.abs(dx) > 35f) {
                            replaySwipe(downX, downY, x, y, duration)
                        }
                    }

                    Mode.FEED_LOCK,
                    Mode.PROFILE_LOCK -> {
                        // Taps are replayed so buttons/profile controls remain usable.
                        // Any meaningful vertical/horizontal movement is consumed.
                        if (kotlin.math.abs(dx) < 18f && kotlin.math.abs(dy) < 18f) {
                            replayTap(x, y)
                        }
                    }

                    Mode.BLOCK_SCREEN -> {
                        // Intentionally consume all touches in the restricted content area.
                    }

                    Mode.NONE -> Unit
                }
                return true
            }
        }
        return true
    }

    private fun replayTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(
            path, 0L, 40L
        )
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }

    private fun replaySwipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(
            path, 0L, duration.coerceAtLeast(100L)
        )
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }

    private fun removeOverlay() {
        mainHandler.post {
            overlay?.let {
                try {
                    (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
                } catch (_: Exception) {}
            }
            overlay = null
            mode = Mode.NONE
        }
    }

    private fun openDirectMessages() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("instagram://direct/inbox"))
            intent.setPackage(INSTAGRAM)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/direct/inbox/"))
            fallback.setPackage(INSTAGRAM)
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(fallback)
        }
    }
}
